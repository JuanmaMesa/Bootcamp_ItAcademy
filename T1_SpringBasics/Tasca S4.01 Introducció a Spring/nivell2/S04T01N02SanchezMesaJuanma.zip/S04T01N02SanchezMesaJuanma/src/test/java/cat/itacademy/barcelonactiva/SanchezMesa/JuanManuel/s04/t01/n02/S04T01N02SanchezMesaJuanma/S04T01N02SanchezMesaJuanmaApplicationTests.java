package cat.itacademy.barcelonactiva.SanchezMesa.JuanManuel.s04.t01.n02.S04T01N02SanchezMesaJuanma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N02SanchezMesaJuanmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
