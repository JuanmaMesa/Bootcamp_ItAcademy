package cat.itacademy.barcelonactiva.SanchezMesa.JuanManuel.s04.t01.n01.S04T01N01SanchezMesaJuanma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N01SanchezMesaJuanmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
