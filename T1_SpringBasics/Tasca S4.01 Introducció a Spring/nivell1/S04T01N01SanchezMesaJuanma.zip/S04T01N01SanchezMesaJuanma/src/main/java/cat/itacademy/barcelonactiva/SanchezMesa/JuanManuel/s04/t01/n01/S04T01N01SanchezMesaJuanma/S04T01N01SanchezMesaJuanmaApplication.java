package cat.itacademy.barcelonactiva.SanchezMesa.JuanManuel.s04.t01.n01.S04T01N01SanchezMesaJuanma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T01N01SanchezMesaJuanmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T01N01SanchezMesaJuanmaApplication.class, args);
	}

}
