package cat.itacademy.barcelonactiva.SanchezMesa.JuanManuel.s04.t02.n02.S04T02N02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T02N02SanchezMesaJuanManuelApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T02N02SanchezMesaJuanManuelApplication.class, args);
	}

}
