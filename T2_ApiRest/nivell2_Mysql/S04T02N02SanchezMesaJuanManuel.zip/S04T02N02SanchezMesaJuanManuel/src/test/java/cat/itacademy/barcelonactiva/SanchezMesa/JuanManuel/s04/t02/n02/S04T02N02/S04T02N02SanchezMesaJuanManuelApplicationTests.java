package cat.itacademy.barcelonactiva.SanchezMesa.JuanManuel.s04.t02.n02.S04T02N02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T02N02SanchezMesaJuanManuelApplicationTests {

	@Test
	void contextLoads() {
	}

}
